import tkinter as tk
from tkinter import simpledialog, messagebox
import json
from pathlib import Path
import ipaddress
import subprocess
import platform

USERS_FILE = Path("users.json")
DEFAULT_USERS = {
    "User1": {"role": "user", "password": "<Yahw8Uuh>"},
    "User2": {"role": "user", "password": "<Thagh8eH>"},
    "Admin": {"role": "admin", "password": "<seevu7Voo9so>"},
    "ADMINISTRATOR": {"role": "administrator", "password": "<dee5EiTo1boo>"},
}

def load_users():
    if USERS_FILE.exists():
        try:
            with open(USERS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return DEFAULT_USERS.copy()
    return DEFAULT_USERS.copy()

def save_users(users):
    with open(USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=4, ensure_ascii=False)

def ip_ping(ip_str):
    try:
        ipaddress.ip_address(ip_str)
    except ValueError:
        return None
    count_param = "-n" if platform.system().lower().startswith("win") else "-c"
    cmd = ["ping", count_param, "1", ip_str]
    result = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return result.returncode == 0

def prompt_ip():
    ip = simpledialog.askstring("Ping IP", "Введите IP-адрес для пинга:")
    if not ip:
        return
    res = ip_ping(ip)
    if res is None:
        messagebox.showerror("Ошибка", "Невалидный IP-адрес!")
    elif res:
        messagebox.showinfo("Ping", f"IP {ip} доступен.")
    else:
        messagebox.showwarning("Ping", f"IP {ip} недоступен.")

def change_password(users, username):
    new_pw = simpledialog.askstring("Смена пароля", "Введите новый пароль:", show='*')
    if new_pw:
        users[username]["password"] = new_pw
        save_users(users)
        messagebox.showinfo("Пароль", "Пароль успешно изменён.")

def admin_menu(users, username):
    while True:
        choice = simpledialog.askstring("Меню администратора",
                                        "1) Список пользователей\n"
                                        "2) Добавить пользователя\n"
                                        "3) Удалить пользователя\n"
                                        "4) Изменить пароль пользователя\n"
                                        "5) Пинг IP\n"
                                        "6) Сменить свой пароль\n"
                                        "0) Выйти\n"
                                        "Выберите опцию:")
        if not choice or choice == "0":
            break
        elif choice == "1":
            msg = "\n".join([f"{u} ({meta['role']})" for u, meta in users.items()])
            messagebox.showinfo("Пользователи", msg)
        elif choice == "2":
            uname = simpledialog.askstring("Добавить пользователя", "Имя:")
            if not uname or uname in users:
                messagebox.showerror("Ошибка", "Пользователь пустой или уже существует!")
                continue
            role = simpledialog.askstring("Роль", "user/admin/administrator:").lower()
            if role not in ("user","admin","administrator"): role="user"
            pw = simpledialog.askstring("Пароль", "Пароль:", show='*')
            users[uname] = {"role": role, "password": pw}
            save_users(users)
            messagebox.showinfo("OK", f"Пользователь {uname} добавлен.")
        elif choice == "3":
            uname = simpledialog.askstring("Удаление", "Имя пользователя:")
            if uname in users and uname != username:
                users.pop(uname)
                save_users(users)
                messagebox.showinfo("OK", "Пользователь удалён.")
        elif choice == "4":
            uname = simpledialog.askstring("Смена пароля", "Имя пользователя:")
            if uname in users:
                new_pw = simpledialog.askstring("Новый пароль", "Введите пароль:", show='*')
                if new_pw:
                    users[uname]["password"] = new_pw
                    save_users(users)
                    messagebox.showinfo("OK", "Пароль изменён.")
        elif choice == "5":
            prompt_ip()
        elif choice == "6":
            change_password(users, username)

def user_menu(users, username):
    while True:
        choice = simpledialog.askstring("Меню пользователя",
                                        "1) Пинг IP\n2) Сменить пароль\n0) Выйти\nВыберите опцию:")
        if not choice or choice=="0": break
        elif choice=="1": prompt_ip()
        elif choice=="2": change_password(users, username)

def main():
    root = tk.Tk()
    root.withdraw()  # скрыть главное окно
    users = load_users()
    while True:
        username = simpledialog.askstring("Вход", "Имя пользователя:")
        if not username: break
        if username not in users:
            messagebox.showerror("Ошибка", "Пользователь не найден")
            continue
        password = simpledialog.askstring("Пароль", "Введите пароль:", show='*')
        if password != users[username]["password"]:
            messagebox.showerror("Ошибка", "Неверный пароль")
            continue
        role = users[username]["role"]
        messagebox.showinfo("Успех", f"Успешный вход: {username} ({role})")
        if role in ("admin","administrator"):
            admin_menu(users, username)
        else:
            user_menu(users, username)

if __name__=="__main__":
    main()